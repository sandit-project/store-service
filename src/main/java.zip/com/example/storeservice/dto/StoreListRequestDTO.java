package com.example.storeservice.dto;

import lombok.Getter;

@Getter
public class StoreListRequestDTO {
    private int limit;
    private Long lastUid;

}
